

<?php $__env->startSection('admin'); ?>

    <div class="py-12">
        <div class="container">
            <div class="row">
<h4>Seccion Slider</h4>
<a href="<?php echo e(route('add.slider')); ?>"><button class="btn btn-info">agregar slider</button></a>
<br><br>
                <div class="col-md-12">
                    <div class="card">

           <?php if(session('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <strong><?php echo e(session('success')); ?></strong> 
                      </div>
            <?php endif; ?>

                        <div class="card-header">Todas los Slider</div>


                 <table class="table table-dark">
                    <thead>
                      <tr>
                        <th scope="col" with="5%">#</th>
                        <th scope="col" with="15%">Titulo del Slides</th>
                        <th scope="col" with="25%">Descripcion</th>
                        <th scope="col" with="15%">Image</th>
                        <th scope="col" with="15%">accion</th>
                      </tr>
                    </thead>
                    <tbody>
                     
                      <?php ($i = 1); ?>
                      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                    
                      <tr>
                        
                            
                       
                        <th scope="row"><?php echo e($i++); ?></th>
                        <td><?php echo e($slider->title); ?></td>
                        <td><?php echo e($slider->description); ?></td>
                        <td><img src="<?php echo e(asset($slider->image)); ?>" style="height: 40px; width:70px" ></td>
                        
                        <td>
                    <a href="<?php echo e(url('slider/edit/'.$slider->id)); ?>" class="btn btn-info">editar</a>
                    <a href="<?php echo e(url('slider/delete/'.$slider->id)); ?>" onclick="return confirm('estas seguro que quieres eliminarlo')" class="btn btn-danger">eliminar</a>
                  </td>
                     
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

           
                  </table>
               
                </div>
            </div>
           
            </div>
        </div>






       
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landingpage\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>