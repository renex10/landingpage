
<?php $__env->startSection('admin'); ?>
    
    <?php if(session('sucess')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong><?php echo e(session('success')); ?></strong> 
    </div>
<?php endif; ?>

    <div class="py-12">
        <div class="container">
            <div class="row">


            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                       editar Slider
                    </div>
                    <div class="card-body">



                    

                    <form action="<?php echo e(url('slider/update/'.$sliders->id)); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>

                      <input type="hidden" name="old_image" value="<?php echo e($sliders->image); ?>">
            
        


                        <div class="form-group">
                          <label for="email">actulizar  titulo</label>
                          <input type="text" name="title" class="form-control" placeholder="ingrese nombre" id="email" value="<?php echo e($sliders->title); ?>">
                         
                          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>

                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                          <label for="email">actulizar Descripcion</label>
                          <input type="text" name="description" class="form-control" placeholder="ingrese nombre" id="email" value="<?php echo e($sliders->description); ?>">
                         
                          <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>

                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="form-group">
                            <label for="email">actulizar imagen de la marca</label>
                            <input type="file" name="image" class="form-control"  id="email" value="<?php echo e($sliders->image); ?>">
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
  
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>





                          <div class="form-group">
                            <img src="<?php echo e(asset($sliders->image)); ?>" style="width:400px;height:200px;">
                          </div>

                          
                        
                        <button type="submit" class="btn btn-primary">actualizar marca</button>
                      </form>
                    </div>
                </div>
            </div>
            </div>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landingpage\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>