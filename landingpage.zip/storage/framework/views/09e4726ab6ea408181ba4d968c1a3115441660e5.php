

<div class="slider-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                
                <!-- Image Slider -->
                <div class="slider-container">
                    <div class="swiper-container image-slider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-1.png')); ?>"  alt="alternative">
                            </div>
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-2.png')); ?>"  alt="alternative">
                            </div>
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-3.png')); ?>"  alt="alternative">
                            </div>
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-4.png')); ?>"  alt="alternative">
                            </div>
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-5.png')); ?>"  alt="alternative">
                            </div>
                            <div class="swiper-slide">
                                    <img class="img-fluid" src= "<?php echo e(asset('fontend/images/customer-logo-6.png')); ?>"  alt="alternative">
                            </div>
                        </div> <!-- end of swiper-wrapper -->
                    </div> <!-- end of swiper container -->
                </div> <!-- end of slider-container -->
                <!-- end of image slider -->

            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <?php /**PATH C:\xampp\htdocs\landingpage\resources\views/layouts/body/slider.blade.php ENDPATH**/ ?>