<?php
$sliders= DB::table('sliders')->get();
?>

<div class="slider-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">      
                
                <!-- Text Slider -->
                <div class="slider-container">
                    <div class="swiper-container text-slider">
                        <div class="swiper-wrapper">
                            
                            <!-- Slide -->
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                         
                            <div class="swiper-slide">
                                <div class="image-wrapper">
                                    <img class="img-fluid" src= <?php echo e($slider->image); ?> alt="alternative">
                                </div> <!-- end of image-wrapper -->
                                <div class="text-wrapper">
                                    <div class="testimonial-text"><?php echo e($slider->description); ?></div>
                                    <div class="testimonial-author"><?php echo e($slider->title); ?></div>
                                </div> <!-- end of text-wrapper -->
                            </div> <!-- end of swiper-slide -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- end of slide -->

                            <!-- Slide -->
                          <!-- end of swiper-slide -->
                            <!-- end of slide -->

                            <!-- Slide -->
                           
                            <!-- end of slide -->

                            <!-- end of slide -->

                        </div> <!-- end of swiper-wrapper -->
                        
                        <!-- Add Arrows -->
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        <!-- end of add arrows -->

                    </div> <!-- end of swiper-container -->
                </div> <!-- end of slider-container -->
                <!-- end of text slider -->

            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div><?php /**PATH C:\xampp\htdocs\landingpage\resources\views/layouts/body/testimonials.blade.php ENDPATH**/ ?>