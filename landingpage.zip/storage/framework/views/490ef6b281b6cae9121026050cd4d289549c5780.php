

<?php $__env->startSection('admin'); ?>

    <div class="py-12">
        <div class="container">
            <div class="row">


                <div class="col-md-8">
                    <div class="card">

           <?php if(session('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <strong><?php echo e(session('success')); ?></strong> 
                      </div>
            <?php endif; ?>

                        <div class="card-header">Todas las Marcas</div>


                 <table class="table table-dark">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">nombre de la marca</th>
                        <th scope="col">imagen de la marca</th>
                        <th scope="col">creado</th>
                        <th scope="col">accion</th>
                      </tr>
                    </thead>
                    <tbody>
                     
                      <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                    
                      <tr>
                        
                            
                        <th scope="row"><?php echo e($brands->firstItem()+$loop->index); ?></th>
                       
                        <td><?php echo e($brand->brand_name); ?></td>
                        <td><img src="<?php echo e(asset($brand->brand_image)); ?>" style="height: 40px; width:70px" ></td>
                        <td>
                          <?php if($brand->created_at == NULL): ?>
                          <span class="text-danger">no hay datos en la base de datos</span>
                          <?php else: ?>
                          <?php echo e($brand->created_at->diffForHumans()); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                    <a href="<?php echo e(url('brand/edit/'.$brand->id)); ?>" class="btn btn-info">editar</a>
                    <a href="<?php echo e(url('brand/delete/'.$brand->id)); ?>" onclick="return confirm('estas seguro que quieres eliminarlo')" class="btn btn-danger">eliminar</a>
                  </td>
                     
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

           
                  </table>
                  <?php echo e($brands->links()); ?>

                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        Agregar Marca
                    </div>
                    <div class="card-body">

                    

                    <form action="<?php echo e(route('store.brand')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="email">Nombre de la marca</label>
                        <input type="text" name="brand_name" class="form-control" placeholder="ingrese la marca" id="email">
                        <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>





                        <div class="form-group">
                          <label for="email">Imagen de la marca</label>
                          <input type="file" name="brand_image" class="form-control"  id="email">
                          <?php $__errorArgs = ['brand_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>

                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Agregar Marca</button>
                      </form>
                    </div>
                </div>
            </div>
            </div>
        </div>






       
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\landingpage\resources\views/admin/brand/index.blade.php ENDPATH**/ ?>